/*
    blogcprog.com - DB
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __DB__
#define __DB__

/* *********************************************************************
 * file     : db
 * purpose  : This db solution is to provide an easy and usable
 *            dynamic memory handling API for C developers,
 *            containing all of the well known solutions in this theme,
 *            so the SQL design as solution is more than welcome in this
 *            development.
 * status   : UNDER CONSTRUCTION
 * ********************************************************************* */

#include "db_general.h"
#include "db_error.h"
#include "db_field.h"
#include "db_index.h"
#include "db_record.h"
#include "db_table.h"
#include "db_cursor.h"

#define db_t_rec_def __db_record_s_definition*
#define db_t_rec __db_record_s_record*
#define db_t_fld __db_field_s_field*
#define db_t_pk __db_index_s_index
#define db_t_idx __db_index_s_index
#define db_t_tab __db_table_s_table*
#define db_t_cur __db_cursor_s_cursor*
#define db_t_key __db_cursor_s_key*

#define db_cre_rec_def(p_num_of_fld) db_record_create_definition(p_num_of_fld)
#define db_set_rec_def_fld(p_rec_def, p_fld_idx, p_fld_name, p_null_def, p_data_type) \
    db_record_set_definition_field(p_rec_def, p_fld_idx, p_fld_name, p_null_def, p_data_type)

#define db_cre_pk(p_num_of_fld) db_index_create(p_num_of_fld, __primary, NULL)

#define db_set_idx_fld(p_idx_fld_def, p_pos, p_idx_fld_pos, p_sort_typ) \
    db_index_set_field_definition(p_idx_fld_def.index_fields_definition, \
        p_pos, p_idx_fld_pos, p_sort_typ)

#define db_cre_tab(p_rec_def, p_pk) db_table_create(p_rec_def, p_pk)

#define db_set_fk_fld_tab(p_tab, p_fld_pos, p_fk_tab)\
    db_table_set_foreign_key(p_tab, p_fld_pos, p_fk_tab);

#define db_cre_idx(p_num_of_fld, p_idx_typ) db_index_create(p_num_of_fld, p_idx_typ, NULL)
#define db_cre_idx_f(p_num_of_fld, p_idx_typ, p_f) db_index_create(p_num_of_fld, p_idx_typ, p_f)
#define db_set_tab_idx(p_tab, p_pos, p_idx) db_table_set_index(p_tab, p_pos, p_idx)

#define db_cre_cur(p_tab, p_idx) db_cursor_create(p_tab, p_idx)
#define db_cre_key(p_cur) db_cursor_create_key(p_cur)
#define db_set_key_fld(p_key, p_pos, p_val) db_cursor_set_key_fields(p_key, p_pos, p_val)
#define db_fnd_by_key(p_key) db_cursor_find_by_key(p_key)

#define db_ins_pre(p_num_of_fld) db_field_create(p_num_of_fld)
#define db_ins_set_fld(p_rec_def, p_fld, p_idx, p_val) \
            db_field_set_value(p_rec_def->fields_definition, p_fld, p_idx, p_val)
#define db_ins_exe(p_cur, p_fld) db_cursor_insert(p_cur, p_fld)

#define db_upd(p_cur, p_fld_pos, p_val) db_cursor_update(p_cur, p_fld_pos, p_val)
#define db_upd_fk(p_cur, p_fld_pos, p_fk_cur) db_cursor_update_fk(p_cur, p_fld_pos, p_fk_cur)

#define db_get_f_cha(p_rec, p_pos) db_field_get_char(p_rec->fields, p_pos)
#define db_get_f_uns_cha(p_rec, p_pos) db_field_get_unsigned_char(p_rec->fields, p_pos)
#define db_get_f_int(p_rec, p_pos) db_field_get_int(p_rec->fields, p_pos)
#define db_get_f_uns_int(p_rec, p_pos) db_field_get_unsigned_int(p_rec->fields, p_pos)
#define db_get_f_lon(p_rec, p_pos) db_field_get_long(p_rec->fields, p_pos)
#define db_get_f_uns_lon(p_rec, p_pos) db_field_get_unsigned_long(p_rec->fields, p_pos)
#define db_get_f_flo(p_rec, p_pos) db_field_get_float(p_rec->fields, p_pos)
#define db_get_f_dou(p_rec, p_pos) db_field_get_double(p_rec->fields, p_pos)
#define db_get_f_voi(p_rec, p_pos) db_field_get_void(p_rec->fields, p_pos)
#define db_get_f_cha_arr(p_rec, p_pos) db_field_get_char_array(p_rec->fields, p_pos)
#define db_get_f_fk_rec(p_rec, p_pos) ((__db_record_s_record*)db_field_get_void(p_rec->fields, p_pos))

#define db_drp_key(p_key) db_cursor_drop_key(p_key)
#define db_drp_cur(p_cur) db_cursor_drop(p_cur)
#define db_drp_tab(p_tab) db_table_drop(p_tab)

#endif

