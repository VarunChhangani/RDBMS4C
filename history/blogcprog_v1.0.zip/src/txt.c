/* 
    blogcprog.com - Texts  
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "txt.h"

char* txt$g_remove_EOL(const char* p_line){
    int v_line_length;
    char* v_line;
    char* v_result = NULL;
    if(p_line != NULL){
        v_line_length = strlen(p_line);
        v_line = malloc(sizeof(char)*(v_line_length + 1));
        strcpy(v_line, p_line);
        if (v_line_length > 0 && v_line[v_line_length-1] == '\n') 
            v_line[--v_line_length] = '\0';
        if (v_line_length > 0 && v_line[v_line_length-1] == '\r') 
            v_line[--v_line_length] = '\0';
        v_result = malloc(sizeof(char) * (v_line_length + 1));
        strcpy(v_result, v_line);
    }
    return v_result;
}

__smemlist* txt$read(const char* p_file_name, 
                       const int p_max_line_size){
    __smemlist* v_result;
    FILE* v_file;
    char* v_line;
    char* v_line2;
    if(p_file_name != NULL){
        v_file = fopen(p_file_name, "r");
        if(v_file != NULL && v_file != 0){
            v_result = memlist$create();
            while(!feof(v_file)){
                v_line = malloc(sizeof(char) * p_max_line_size);
                fgets(v_line, p_max_line_size, v_file);
                v_line2 = txt$g_remove_EOL(v_line);
                free(v_line);
                memlist$put_element(v_result, v_line2);
            }
            fclose(v_file);
        }
    }
    return v_result;
}
