/* 
    blogcprog.com - List in the memory 
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdlib.h>
#include "memlist.h"

__smemlist* memlist$create(void){
    __smemlist* v_memlist;
    v_memlist = malloc(sizeof(__smemlist));
    v_memlist->memlist_list_first_element = NULL;
    v_memlist->memlist_list_last_element = NULL;
	v_memlist->count = 0;
    return v_memlist;
}

__smemlistelement* memlist$put_element(__smemlist* p_memlist, void* p_element){
    __smemlistelement* v_memlistelement = NULL;
    if(p_memlist != NULL){
        v_memlistelement = malloc(sizeof(__smemlistelement));
        v_memlistelement->prev_memlistelement = p_memlist->memlist_list_last_element;
        v_memlistelement->next_memlistelement = NULL;
        v_memlistelement->element = p_element;
        p_memlist->count++;
        if(p_memlist->memlist_list_last_element!=NULL){
            p_memlist->memlist_list_last_element->next_memlistelement = v_memlistelement;
        }
        p_memlist->memlist_list_last_element = v_memlistelement;
        if(p_memlist->memlist_list_first_element == NULL) 
            p_memlist->memlist_list_first_element = v_memlistelement;
    }
    return v_memlistelement;
}

__smemlistelement* memlist$insert_element(__smemlist* p_memlist, void* p_element){
    __smemlistelement* v_memlistelement = NULL;
    if(p_memlist != NULL){
        v_memlistelement = malloc(sizeof(__smemlistelement));
        v_memlistelement->prev_memlistelement = NULL;
        v_memlistelement->element = p_element;
        p_memlist->count++;
        if(p_memlist->memlist_list_first_element != NULL){
            v_memlistelement->next_memlistelement = p_memlist->memlist_list_first_element;
            p_memlist->memlist_list_first_element->prev_memlistelement = v_memlistelement;
        }else{
            v_memlistelement->next_memlistelement = NULL;
            p_memlist->memlist_list_last_element = v_memlistelement;
        }
        p_memlist->memlist_list_first_element = v_memlistelement;
    }
    return v_memlistelement;
}

unsigned char memlist$for_all(__smemlist* p_memlist, 
                 __p_memlist_for_function p_memlist_for_function, 
                                    char* p_args[]){
    long l=0;
    unsigned char v_ret=0;
    __smemlistelement* v_memlistelement;
    v_memlistelement = p_memlist->memlist_list_first_element;
	while(v_ret==0&&v_memlistelement!=NULL&&l<p_memlist->count){
        v_ret = (*p_memlist_for_function)(p_memlist, v_memlistelement, p_args, l+1);
        v_memlistelement = v_memlistelement->next_memlistelement;
        l++;
    }
    return v_ret;
}

__smemlistelement* memlist$get_element(__smemlist* p_memlist, const long int p_position){
    long int v_l=0;
    __smemlistelement* v_se = NULL;
    if(p_memlist != NULL && p_position > -1 && p_position < p_memlist->count){
        v_se = p_memlist->memlist_list_first_element;
        while(v_l < p_position && v_se->next_memlistelement != NULL){
            v_se = v_se->next_memlistelement;
            v_l++;
        }
    }
    return v_se;
}

void memlist$delete_element(__smemlist* p_memlist, const long int p_position){
    __smemlistelement* v_se = memlist$get_element(p_memlist, p_position);
    if(v_se != NULL){
        if(p_position == 0){
            p_memlist->memlist_list_first_element = v_se->next_memlistelement;
            if(v_se->next_memlistelement != NULL){
                v_se->next_memlistelement->prev_memlistelement = NULL;
            }
        } else {
            if(v_se->prev_memlistelement != NULL){
                v_se->prev_memlistelement->next_memlistelement = v_se->next_memlistelement;
            }
        }
        free(v_se->element);
        free(v_se);
        p_memlist->count--;
    }
}

void memlist$order(__smemlist* p_memlist, 
    __p_memlist_order_function p_memlist_order_funtion, 
                  __order_type p_order_type){
/* UNDER CONSTRUCTION */
}

void memlist$destroy(__smemlist* p_memlist){
    long l=0;
    __smemlistelement* v_memlistelement;
    __smemlistelement* v_memlistelement_prev;
    v_memlistelement = p_memlist->memlist_list_first_element;
    while(v_memlistelement != NULL && l < p_memlist->count){
        v_memlistelement_prev = v_memlistelement;
        v_memlistelement = v_memlistelement->next_memlistelement;
        free(v_memlistelement_prev->element);
        free(v_memlistelement_prev);
        l++;
    }
    free(p_memlist);
}    
