/* 
    blogcprog.com - List in the memory 
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __MEMLIST__
#define __MEMLIST__

/* -------------------------------------------------- * 
 * --------------- Type definitions ----------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * typedef  : __order_type
 * purpose  : Enumeration for the order type (ascending, descending)
 * ********************************************************************* */
typedef enum {ascending=0, descending=1} __order_type;

/* ********************************************************************* 
 * typedef  : __smemlistelement
 * purpose  : Element type in the memory list 
 * ********************************************************************* */
typedef struct ssmemlistelement{
    void* element;
    struct ssmemlistelement* prev_memlistelement;
    struct ssmemlistelement* next_memlistelement;
} __smemlistelement;

/* ********************************************************************* 
 * typedef  : __smemlist
 * purpose  : Memory list type base structure 
 * ********************************************************************* */
typedef struct ssmemlist{
    __smemlistelement* memlist_list_first_element;
    __smemlistelement* memlist_list_last_element;
    long count;
    unsigned char list_type;
} __smemlist;

/* ********************************************************************* 
 * typedef  : __memlist_order_function
 * purpose  : Event function type to provide order rules
  * ********************************************************************* */
typedef void __memlist_order_function();

/* ********************************************************************* 
 * typedef  : __memlist_for_function
 * purpose  : Event function type to provide the event function in a FOR cicle 
 * ********************************************************************* */
typedef unsigned char __memlist_for_function(__smemlist* p_memlist, 
                                      __smemlistelement* p_memlistelement, 
                                                   char* p_args[], 
                                                    long p_rownum);

/* ********************************************************************* 
 * typedef  : __p_memlist_order_function
 * purpose  : Pointer type for __memlist_order_function
 * ********************************************************************* */
typedef __memlist_order_function* __p_memlist_order_function;

/* ********************************************************************* 
 * typedef  : __p_memlist_for_function
 * purpose  : Pointer type for __memlist_for_function
 * ********************************************************************* */
typedef __memlist_for_function* __p_memlist_for_function;

/* -------------------------------------------------- * 
 * ----------- End of the Type definitions ---------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- * 
 * ------------------- Functions -------------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * function : memlist$create
 * purpose  : Create memlist
 * ********************************************************************* */
__smemlist* memlist$create(void);

/* ********************************************************************* 
 * function : memlist$put_element
 * purpose  : Put element to the end of the list
 * ********************************************************************* */
__smemlistelement* memlist$put_element(__smemlist* p_memlist, void* p_element);

/* ********************************************************************* 
 * function : memlist$insert_element
 * purpose  : Insert element to the begin of the list
 * ********************************************************************* */
__smemlistelement* memlist$insert_element(__smemlist* p_memlist, void* p_element);

/* ********************************************************************* 
 * function : memlist$get_element
 * purpose  : get element from the position (position from 0)
 * ********************************************************************* */
__smemlistelement* memlist$get_element(__smemlist* p_memlist, const long int p_position);

/* ********************************************************************* 
 * function : memlist$delete_element
 * purpose  : delete element from the position (position from 0)
 * ********************************************************************* */
void memlist$delete_element(__smemlist* p_memlist, const long int p_position);

/* ********************************************************************* 
 * function : memlist$order
 * purpose  : Order the list
 * ********************************************************************* */
void memlist$order(__smemlist* p_memlist, 
    __p_memlist_order_function p_memlist_order_funtion, 
                  __order_type p_order_type);

/* ********************************************************************* 
 * function : memlist$for_all
 * purpose  : loop statement on the list elements
 * ********************************************************************* */
unsigned char  memlist$for_all(__smemlist* p_memlist, 
                  __p_memlist_for_function p_memlist_for_function, 
                                     char* p_args[]);

/* ********************************************************************* 
 * function : memlist$destroy
 * purpose  : Destroy the list. 
 *            Please note, that it works only when the calling of the "free" 
 *            function is possible on all of the put data in the list.
 * ********************************************************************* */
void memlist$destroy(__smemlist* p_memlist);

/* -------------------------------------------------- * 
 * --------------- End of the Functions ------------- *
 * -------------------------------------------------- * */

#endif
