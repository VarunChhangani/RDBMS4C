/*
    blogcprog.com - db_string
    Copyright (C) 2011  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __DB_STRING__
#define __DB_STRING__

/* *********************************************************************
 * file     : db_string
 * purpose  : String solution to avoid the pointer problems at the char*
 *            functions beginning with db_string_g_ : gives new instance
 *            functions beginning with db_string_s_ : updates the original one
 * ********************************************************************* */


/* *********************************************************************
 * typedef  : __db_string_s
 * purpose  : Structure for db_string
 * ********************************************************************* */

/* -------------------------------------------------- *
 * --------------- Type definitions ----------------- *
 * -------------------------------------------------- * */

/* *********************************************************************
 * typedef  : __db_string_s
 * purpose  : Structure for db_string
 * ********************************************************************* */
typedef struct __db_string_ss {
    char *str;
} __db_string_s;

/* *********************************************************************
 * typedef  : __db_string
 * purpose  : db string base type
 * ********************************************************************* */
typedef __db_string_s* __db_string;


/* -------------------------------------------------- *
 * ----------- End of the Type definitions ---------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- *
 * ------------------- Functions -------------------- *
 * -------------------------------------------------- * */

/* *********************************************************************
 * function : db_string_create
 * purpose  : Create db string using p_str base string
 * ********************************************************************* */
__db_string db_string_create(const char *p_str);

/* *********************************************************************
 * function : db_string_drop
 * purpose  : Drop p_db_string
 * ********************************************************************* */
void db_string_drop(__db_string p_db_string);

/* *********************************************************************
 * function : db_string_assign
 * purpose  : Assign p_str into p_s.
 * ********************************************************************* */
void db_string_s_assign(__db_string p_s, const char *p_str);

/* *********************************************************************
 * function : db_string_concat
 * purpose  : Concats p_str to p_s.
 * ********************************************************************* */
void db_string_s_concat(__db_string p_s, const char *p_str);

/* *********************************************************************
 * function : db_string_begins_with
 * purpose  : Returns with 1 when p_s begins with p_s2, otherwise returns with 0.
 * ********************************************************************* */
unsigned char db_string_begins_with(__db_string p_s, __db_string p_s2);

/* *********************************************************************
 * function : db_string_ends_with
 * purpose  : Returns with 1 when p_s ends with p_s2, otherwise returns with 0.
 * ********************************************************************* */
unsigned char db_string_ends_with(__db_string p_s, __db_string p_s2);

/* *********************************************************************
 * function : db_string_g_csv_element
 * purpose  : Returns with p_i th element from p_line csv string using
 *            p_delimiter and p_opt_enclosed.
 * ********************************************************************* */
__db_string db_string_g_csv_element(__db_string p_line,
                                      const int p_i,
                                     const char p_delimiter,
                                     const char p_opt_enclosed);

/* *********************************************************************
 * function : db_string_g_substr
 * purpose  : Return with a NEW allocated db_string which contains the
 *            substring from p_s begining from the position p_x on p_n char.
 *            The positions are based on 0.
 * ********************************************************************* */
__db_string db_string_g_substr(__db_string p_s, const int p_x, const int p_n);

/* *********************************************************************
 * function : db_string_s_substr
 * purpose  : p_s will contain the substring value from the original p_s.
 *            The original p_s->str value will be freed.
 * ********************************************************************* */
void db_string_s_substr(__db_string p_s, const int p_x, const int p_n);

/* *********************************************************************
 * function : db_string_g_trim
 * purpose  : Return with a NEW allocated db string which is based on p_s and
 *            trimed  (left-right) with the char p_c.
 * ********************************************************************* */
__db_string db_string_g_trim(__db_string p_s, const char p_c);

/* *********************************************************************
 * function : db_string_s_trim
 * purpose  : p_s will contain the trimed value from the original p_s.
 *            The original p_s->str value will be freed.
 * ********************************************************************* */
void db_string_s_trim(__db_string p_s, const char p_c);

/* *********************************************************************
 * function : db_string_g_lpad
 * purpose  : Return with a NEW allocated db string which is based on p_s and
 *            lpadded with the char p_c.
 * ********************************************************************* */
__db_string db_string_g_lpad(__db_string p_s, const int p_n, const char p_c);

/* *********************************************************************
 * function : db_string_s_lpad
 * purpose  : p_s will contain the lpadded value from the original p_s.
 *            The original p_s->str value will be freed.
 * ********************************************************************* */
void db_string_s_lpad(__db_string p_s, const int p_n, const char p_c);

/* *********************************************************************
 * function : db_string_g_rpad
 * purpose  : Return with a NEW allocated db string which is based on p_s and
 *            rpadded with the char p_c.
 * ********************************************************************* */
__db_string db_string_g_rpad(__db_string p_s, const int p_n, const char p_c);

/* *********************************************************************
 * function : db_string_s_rpad
 * purpose  : p_s will contain the rpadded value from the original p_s.
 *            The original p_s->str value will be freed.
 * ********************************************************************* */
void db_string_s_rpad(__db_string p_s, const int p_n, const char p_c);

/* *********************************************************************
 * function : db_string_g_inch
 * purpose  : Return with the first position of p_c char in the db string p_s
 *            from the position p_x. The positions are based on 0.
 *            In case of missing p_c in s return with -1.
 * ********************************************************************* */
int db_string_g_inch(__db_string p_s, const char p_c, const int p_x);

/* *********************************************************************
 * function : db_string_g_instr
 * purpose  : Return with the first position of p_s2 db string
 *            in the db string p_s from the position p_x. The positions are
 *            based on 0. In case of missing p_s2 in p_s return with -1.
 * ********************************************************************* */
int db_string_g_instr(__db_string p_s, __db_string p_s2, const int p_x);

/* *********************************************************************
 * function : db_string_g_ins
 * purpose  : Return with a NEW allocated db string which contains the
 *            inserted p_s2 db string into the db string p_s at the p_x position.
 * ********************************************************************* */
__db_string db_string_g_ins(__db_string p_s, __db_string p_s2, const int p_x);

/* *********************************************************************
 * function : db_string_s_ins
 * purpose  : Inserts p_s2 db string into the db string p_s at the p_x position.
 * ********************************************************************* */
void db_string_s_ins(__db_string p_s, __db_string p_s2, const int p_x);

/* *********************************************************************
 * function : db_string_g_replace
 * purpose  : Return with a NEW allocated db string which is
 *            based on p_s but the p_s1 substrings are replaced with p_s2.
 * ********************************************************************* */
__db_string db_string_g_replace(__db_string p_s, __db_string p_s1, __db_string p_s2);

/* *********************************************************************
 * function : db_string_s_replace
 * purpose  : Replaces the p_s1 substrings with p_s2 in p_s.
 * ********************************************************************* */
void db_string_s_replace(__db_string p_s, __db_string p_s1, __db_string p_s2);

/* -------------------------------------------------- *
 * --------------- End of the Functions ------------- *
 * -------------------------------------------------- * */

#endif
