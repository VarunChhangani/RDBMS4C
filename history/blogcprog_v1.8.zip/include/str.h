/*
    blogcprog.com - C string utility
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __STR__
#define __STR__

/* *********************************************************************
 * file     : str
 * purpose  : This str solution is to provide an easy and usable
 *            string handling API for C developers,
 *            containing all of the well known solutions in this theme,
 *            as the base string handling possibility is not easy in the
 *            ANSI C language.
 *            Important to combine the ANSI C string solutions with the
 *            well known PL/SQL solutions.
 *
 * ********************************************************************* */

/* -------------------------------------------------- *
 * ------------------- Functions -------------------- *
 * -------------------------------------------------- * */

/* *********************************************************************
 * function : str_is_letter
 * purpose  : Returns with 1 when p_c is letter, otherwise returns with 0.
 * ********************************************************************* */
unsigned char str_is_letter(const char p_c);

/* *********************************************************************
 * function : str_begins_with
 * purpose  : Returns with 1 when p_s begins with p_s2, otherwise returns with 0.
 * ********************************************************************* */
unsigned char str_begins_with(const char* p_s, const char* p_s2);

/* *********************************************************************
 * function : str_ends_with
 * purpose  : Returns with 1 when p_s ends with p_s2, otherwise returns with 0.
 * ********************************************************************* */
unsigned char str_ends_with(const char* p_s, const char* p_s2);

/* *********************************************************************
 * function : str_g_csv_element
 * purpose  : Returns with p_i th element from p_line csv string using
 *            p_delimiter and p_opt_enclosed.
 * ********************************************************************* */
char* str_g_csv_element(const char* p_line,
                          const int p_i,
                         const char p_delimiter,
                         const char p_opt_enclosed);

/* *********************************************************************
 * function : str_g_inch
 * purpose  : Return with the first position of p_c char in the string p_s
 *            from the position p_x. The positions are based on 0.
 *            In case of missing p_c in s return with -1.
 * ********************************************************************* */
int str_g_inch(const char* p_s, const char p_c, const int p_x);

/* *********************************************************************
 * function : str_g_instr
 * purpose  : Return with the first position of p_s2 string in the string p_s
 *            from the position p_x. The positions are based on 0.
 *            In case of missing p_s2 in p_s return with -1.
 * ********************************************************************* */
int str_g_instr(const char* p_s, const char* p_s2, const int p_x);

/* *********************************************************************
 * function : str_g_ins
 * purpose  : Return with a NEW allocated string which contains the
 *            inserted p_s2 string in the string p_s at the p_x position.
 * ********************************************************************* */
char* str_g_ins(const char* p_s, const char* p_s2, const int p_x);

/* *********************************************************************
 * function : str_g_left
 * purpose  : Return with a NEW allocated string which contains
 *            the first p_n char from the string p_s.
 * ********************************************************************* */
char* str_g_left(const char* p_s, const int p_n);

/* *********************************************************************
 * function : str_g_lpad
 * purpose  : Return with a NEW allocated string which contains
 *            the p_s string left padded with p_c on p_n digits.
 *            In case of p_n < length of p_s the result is the first p_n
 *            digits from p_s.
 * ********************************************************************* */
char* str_g_lpad(const char* p_s, const int p_n, const char p_c);

/* *********************************************************************
 * function : str_g_repeat
 * purpose  : Return with a NEW allocated string which
 *            contains the p_c char on p_n digits.
 * ********************************************************************* */
char* str_g_repeat(const char p_c, const int p_n);

/* *********************************************************************
 * function : str_g_replace
 * purpose  : Return with a NEW allocated string which is
 *            based on p_s but the p_s1 substrings are replaced with p_s2.
 * ********************************************************************* */
char* str_g_replace(const char* p_s, const char* p_s1, const char* p_s2);

/* *********************************************************************
 * function : str_g_right
 * purpose  : Return with a NEW allocated string which contains
 *            the last p_n char from the string p_s.
 * ********************************************************************* */
char* str_g_right(const char* p_s, const int p_n);

/* *********************************************************************
 * function : str_g_rpad
 * purpose  : Return with a NEW allocated string which contains
 *            the p_s string right padded with p_c on p_n digits.
 *            In case of p_n < legth of p_s the result is the first p_n
 *            digits from p_s.
 * ********************************************************************* */
char* str_g_rpad(const char* p_s, const int p_n, const char p_c);

/* *********************************************************************
 * function : str_g_substr
 * purpose  : Return with a NEW allocated string which contains the substring
 *            from p_s begining from the position p_x on p_n char.
 *            The positions are based on 0.
 * ********************************************************************* */
char* str_g_substr(const char* p_s, const int p_x, const int p_n);

/* *********************************************************************
 * function : str_g_trim
 * purpose  : Return with a NEW allocated string which is based on p_s and
 *            trimed  (left-right) with the char p_c.
 * ********************************************************************* */
char* str_g_trim(const char* p_s, const char p_c);

/* -------------------------------------------------- *
 * --------------- End of the Functions ------------- *
 * -------------------------------------------------- * */

#endif
