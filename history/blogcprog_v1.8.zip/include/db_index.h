/*
    blogcprog.com - db_index
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __DB_INDEX__
#define __DB_INDEX__

/* *********************************************************************
 * file     : db_index
 * purpose  : Indexes
 *
 * ********************************************************************* */
#include <stdlib.h>
#include "db_record.h"

/* -------------------------------------------------- *
 * --------------- Type definitions ----------------- *
 * -------------------------------------------------- * */

/* *********************************************************************
 * typedef  : __db_index_index_type
 * purpose  : Index types (currently not used)
 * ********************************************************************* */
typedef enum {__normal = 1, __primary = 2, __unique = 3} __db_index_index_type;

/* *********************************************************************
 * typedef  : __db_index_field_sort_type
 * purpose  : Index filed sort type (currently not used)
 * ********************************************************************* */
typedef enum {__asc = 0, __desc = 1} __db_index_field_sort_type;

/* *********************************************************************
 * typedef  : __db_index_position
 * purpose  : Index position in the table indexes
 * ********************************************************************* */
typedef unsigned char __db_index_position;

/* *********************************************************************
 * typedef  : __db_index_record_position
 * purpose  : Record position in an index
 * ********************************************************************* */
typedef unsigned long __db_index_record_position;

/* *********************************************************************
 * typedef  : __db_index_index
 * purpose  : Index base type
 * ********************************************************************* */
typedef __db_record_s_record** __db_index_index;

/* *********************************************************************
 * typedef  : __db_index_function_based
 * purpose  : Function type for indexes, return with 1 if the p_record_1
 *            is greater than the p_record_2.
 * ********************************************************************* */
typedef int __db_index_function_based(const __db_record_s_record* p_record_1,
                                      const __db_record_s_record* p_record_2);

/* *********************************************************************
 * typedef  : __db_index_p_function_based
 * purpose  : Pointer type for __db_index_function_based
 * ********************************************************************* */
typedef __db_index_function_based* __db_index_p_function_based;

/* *********************************************************************
 * typedef  : __db_index_s_index_field_definition
 * purpose  : Index field definition
 * ********************************************************************* */
typedef struct __db_index_ss_index_field_definition {
    int field_index;
    __db_index_field_sort_type sort_type;
} __db_index_s_index_field_definition;

/* *********************************************************************
 * typedef  : __db_index_s_index
 * purpose  : Index structure
 * ********************************************************************* */
typedef struct __db_index_ss_index {
    __db_index_index index;
    int num_of_index_fields;
    __db_index_s_index_field_definition* index_fields_definition;
    __db_index_p_function_based function_based_index;
    __db_index_index_type index_type;
    unsigned char index_rebuild_needed;
    char enabled;
} __db_index_s_index;

/* -------------------------------------------------- *
 * ----------- End of the Type definitions ---------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- *
 * ------------------- Functions -------------------- *
 * -------------------------------------------------- * */

/* *********************************************************************
 * function : db_index_create
 * purpose  : Create index
 * ********************************************************************* */
__db_index_s_index db_index_create(int p_num_of_index_fields,
                 __db_index_index_type p_index_type,
           __db_index_p_function_based p_f);

/* *********************************************************************
 * function : db_index_set_field_definition
 * purpose  : Set index field definition
 * ********************************************************************* */
void db_index_set_field_definition(
    __db_index_s_index_field_definition* p_index_fields_definition,
                                     int p_position,
                                     int p_field_index,
              __db_index_field_sort_type p_field_sort_type);

/* -------------------------------------------------- *
 * --------------- End of the Functions ------------- *
 * -------------------------------------------------- * */

#endif
