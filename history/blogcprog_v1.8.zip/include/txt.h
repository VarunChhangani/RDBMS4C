/*
    blogcprog.com - Texts
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __TXT__
#define __TXT__

#include <stdio.h>
#include "db.h"

/* *********************************************************************
 * file     : txt
 * purpose  : Text files
 *
 * ********************************************************************* */

/* -------------------------------------------------- *
 * ------------------- Functions -------------------- *
 * -------------------------------------------------- * */


/* *********************************************************************
 * function : txt_read
 * purpose  : Read the text file called p_file_name into a __stable*
 *            variable with p_max_line_size line length limit.
 * ********************************************************************* */
__db_table_s_table* txt_read(const char* p_file_name,
                               const int p_max_line_size);

/* *********************************************************************
 * function : txt_g_remove_EOL
 * purpose  : Return with a NEW allocated string which is based on p_line,
 *            but left trimed with the EOL character(s).
 * ********************************************************************* */
char* txt_g_remove_EOL(const char* p_line);

/* -------------------------------------------------- *
 * --------------- End of the Functions ------------- *
 * -------------------------------------------------- * */

#endif

