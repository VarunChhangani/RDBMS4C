/* 
    blogcprog.com - db_cursor
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdlib.h>
#include "db_cursor.h"

__db_cursor_s_cursor* db_cursor_create(__db_table_s_table* p_table,
                                                       int p_index_position){
    __db_cursor_s_cursor* v_result = NULL;
    if(p_table != NULL && p_index_position >= 0 && p_index_position < 32){
        v_result = malloc(sizeof(__db_cursor_s_cursor));
        v_result->current = 0;
        v_result->index_position = p_index_position;
        v_result->table = p_table;
    }
    return v_result;
}

void db_cursor_drop(__db_cursor_s_cursor* p_cursor){
    if(p_cursor != NULL){
        free(p_cursor);
    }
}

__db_record_s_record* db_cursor_current(__db_cursor_s_cursor* p_cursor){
    __db_record_s_record* v_result = NULL;
    if(p_cursor != NULL && 
       p_cursor->current >= 0 && 
       p_cursor->current < p_cursor->table->count){
        v_result = db_table_get_record(p_cursor->table, 
                                       p_cursor->index_position, 
                                       p_cursor->current);
    }
    return v_result;
}

__db_record_s_record* db_cursor_next(__db_cursor_s_cursor* p_cursor){
    __db_record_s_record* v_result = NULL;
    if(p_cursor != NULL && p_cursor->current < p_cursor->table->count - 1){
        v_result = db_table_get_record(p_cursor->table, 
                                       p_cursor->index_position, 
                                       ++p_cursor->current);
    }
    return v_result;
}

__db_record_s_record* db_cursor_prev(__db_cursor_s_cursor* p_cursor){
    __db_record_s_record* v_result = NULL;
    if(p_cursor != NULL && p_cursor->current > 0){
        v_result = db_table_get_record(p_cursor->table, 
                                       p_cursor->index_position, 
                                       --p_cursor->current);
    }
    return v_result;
}

__db_record_s_record* db_cursor_first(__db_cursor_s_cursor* p_cursor){
    __db_record_s_record* v_result = NULL;
    if(p_cursor != NULL){
        p_cursor->current = 0;
        v_result = db_table_get_record(p_cursor->table, 
                                       p_cursor->index_position, 
                                       p_cursor->current);
    }
    return v_result;
}

__db_record_s_record* db_cursor_last(__db_cursor_s_cursor* p_cursor){
    __db_record_s_record* v_result = NULL;
    if(p_cursor != NULL && p_cursor->table != NULL){
        p_cursor->current = p_cursor->table->count - 1;
        v_result = db_table_get_record(p_cursor->table, 
                                       p_cursor->index_position, 
                                       p_cursor->current);
    }
    return v_result;
}

unsigned char db_cursor_for_all(__db_cursor_s_cursor* p_cursor, 
                           __db_cursor_p_for_function p_cursor_for_function, 
                                                void* p_args[]){
    long l=0;
    unsigned char v_ret=0;
    if(p_cursor != NULL && p_cursor->table != NULL){
        while(v_ret==0 && l < p_cursor->table->count){
            v_ret = (*p_cursor_for_function)
                         (p_cursor->table, 
                          db_table_get_record(p_cursor->table, 
                                              p_cursor->index_position, l), 
                          p_args, l);
            l++;
        }
    }
    return v_ret;
}
