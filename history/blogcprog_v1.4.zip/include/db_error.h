/* 
    blogcprog.com - DB_ERROR 
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __DB_ERROR__
#define __DB_ERROR__

/* ********************************************************************* 
 * file     : db_error
 * purpose  : DB error handling 
 * ********************************************************************* */

/* -------------------------------------------------- * 
 * --------------- Type definitions ----------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * typedef  : __db_error_status 
 * purpose  : Error status 
 * ********************************************************************* */
typedef enum {__NO_ERROR = 0, __ERROR = 1} __db_error_status;

/* ********************************************************************* 
 * typedef  : __db_error_type 
 * purpose  : Error type
 * ********************************************************************* */
typedef enum {__WITHOUT_ERROR = 0, 
         __NOT_NULL_VIOLATION = 100,
      __MISSING_PRIMARY_INDEX = 600,
        __PRIMARY_INDEX_REDEF = 601,
       __PRIMARY_INDEX_DELETE = 602,
  __MISSING_RECORD_DEFINITION = 603,
        __UNIQUE_INDEX_NEEDED = 604} __db_error_type;

/* ********************************************************************* 
 * typedef  : __db_error_s_error 
 * purpose  : Error structure 
 * ********************************************************************* */
typedef struct __db_error_ss_error {
    __db_error_status error_status;
    __db_error_type error_type;
} __db_error_s_error;

/* -------------------------------------------------- * 
 * ----------- End of the Type definitions ---------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- * 
 * --------------- Global variables ----------------- *
 * -------------------------------------------------- * */

__db_error_s_error gv_db_error;

/* -------------------------------------------------- * 
 * ----------- End of the Global variables ---------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- * 
 * ------------------- Functions -------------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * function : db_error_reset
 * purpose  : Reset the gv_db_error variable 
 * ********************************************************************* */
void db_error_reset(void);

/* ********************************************************************* 
 * function : db_error_set_error
 * purpose  : Set error in gv_db_error variable 
 * ********************************************************************* */
void db_error_set_error(__db_error_type p_error_type);

/* ********************************************************************* 
 * function : db_error_is_error 
 * purpose  : Return with 1 in case of error, otherwise returns with 0 
 * ********************************************************************* */
__db_error_status db_error_is_error(void);

/* -------------------------------------------------- * 
 * --------------- End of the Functions ------------- *
 * -------------------------------------------------- * */

#endif







































