/* 
    blogcprog.com - DB
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __DB__
#define __DB__

/* ********************************************************************* 
 * file     : db
 * purpose  : This db solution is to provide an easy and usable 
 *            dynamic memory handling API for C developers, 
 *            containing all of the well known solutions in this theme,
 *            so the SQL design as solution is more than welcome during 
 *            the developing.
 *
 * status   : UNDER CONSTRUCTION 
 * ********************************************************************* */

#include "db_general.h"
#include "db_error.h"
#include "db_field.h"
#include "db_index.h"
#include "db_record.h"
#include "db_table.h"
#include "db_cursor.h"


#endif







































