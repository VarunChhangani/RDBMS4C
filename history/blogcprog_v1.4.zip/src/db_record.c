/* 
    blogcprog.com - db_record
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "stdlib.h"
#include "db_record.h"


__db_record_s_definition* db_record_create_definition(int p_num_of_fields){
    __db_record_s_definition* v_result = NULL;
    __fields_definition v_fields_definition = NULL;
    if (p_num_of_fields > 0){
        v_result = malloc(sizeof(__db_record_s_definition));
        v_fields_definition = malloc(sizeof(__fields_definition*) * p_num_of_fields);
        v_result->fields_definition = v_fields_definition;
        v_result->num_of_fields = p_num_of_fields;
    }
    return v_result;
}

void db_record_set_definition_field(__db_record_s_definition* p_record_definition,
                                                          int p_position, 
                               __db_field_s_field_definition* p_field_definition){
    if (p_record_definition != NULL && 
        p_position >= 0 &&
        p_position < p_record_definition->num_of_fields &&
        p_field_definition != NULL &&
        p_record_definition->fields_definition != NULL){
            p_record_definition->fields_definition[p_position] = p_field_definition;
    }
}

__db_record_s_record* db_record_create(__db_record_s_record* p_prev_record,
                                       __db_record_s_record* p_next_record,
                                           __db_field_fields p_fields){
    __db_record_s_record* v_result = NULL;
    if(p_fields != NULL){
        v_result = malloc(sizeof(__db_record_s_record));
        v_result->prev_record = p_prev_record;
        v_result->next_record = p_next_record;
        v_result->fields = p_fields;
    }
    return v_result;
}

void db_record_drop(__db_record_s_record* p_record,
                __db_record_s_definition* p_record_definition){
    if(p_record != NULL && p_record->fields != NULL){
        if(p_record_definition != NULL){
            db_field_drop(p_record->fields, p_record_definition->num_of_fields);
        }
    }
    if(p_record != NULL){
        free(p_record);
    }
}

void db_record_drop_definition(__db_record_s_definition* p_record_definition){
    int v_i;
    if(p_record_definition != NULL){
        if(p_record_definition->fields_definition != NULL){
            for(v_i = 0; v_i < p_record_definition->num_of_fields; v_i++){
                if(p_record_definition->fields_definition[v_i] != NULL){
                    free(p_record_definition->fields_definition[v_i]);
                }
            }
            free(p_record_definition->fields_definition);
        }
        free(p_record_definition);
    }
}


























