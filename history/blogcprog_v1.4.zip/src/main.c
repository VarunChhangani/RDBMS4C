/*
    blogcprog.com - How to use the blogcprog.com C functions
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "db.h"

/* -------------------------------------------------- *
 * ------------------- Constants -------------------- *
 * -------------------------------------------------- * */
    const int c_index1 = 0;
    const int c_index2 = 1;
    const int c_index3 = 3;

/* -------------------------------------------------- *
 * --------------- End of the Constants ------------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- *
 * ------------------- Variables -------------------- *
 * -------------------------------------------------- * */

    __db_record_s_definition* v_record_definition;
    __db_field_fields v_fields;

    __db_index_s_index* v_primary_index;
    __db_index_s_index* v_index_2;
    __db_index_s_index* v_index_3;

    __db_table_s_table* v_table = NULL;

    __db_cursor_s_cursor* v_cursor1;
    __db_cursor_s_cursor* v_cursor2;
    __db_cursor_s_cursor* v_cursor3;

    __db_cursor_s_key* v_key;

    __db_record_s_record* v_record;

/* -------------------------------------------------- *
 * --------------- End of the Variables ------------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- *
 * ------------------- Functions -------------------- *
 * -------------------------------------------------- * */

void insert(unsigned int p_id,
                   char* p_brand,
                   char* p_name,
                   float p_price){
    v_fields = db_field_create(4);
    db_field_set_value(v_record_definition->fields_definition, v_fields, 0, &p_id);
    db_field_set_value(v_record_definition->fields_definition, v_fields, 1, p_brand);
    db_field_set_value(v_record_definition->fields_definition, v_fields, 2, p_name);
    db_field_set_value(v_record_definition->fields_definition, v_fields, 3, &p_price);
    db_table_insert_into(v_table, v_fields);
}

void list(__db_cursor_s_cursor* p_cursor){
    v_record = db_cursor_first(p_cursor);
    do {
        if(v_record != NULL){
            printf("%i - %s - %s - %f\n", db_field_get_unsigned_int(v_record->fields, 0),
                                          db_field_get_char_array(v_record->fields, 1),
                                          db_field_get_char_array(v_record->fields, 2),
                                          db_field_get_float(v_record->fields, 3)
                                   );
        }
    } while ((v_record = db_cursor_next(p_cursor)) != NULL);
}

/* -------------------------------------------------- *
 * --------------- End of the Functions ------------- *
 * -------------------------------------------------- * */


int main(int argc, char *argv[]){
    /* *********************************************************
     * Define the record definition
     * ********************************************************* */
int ii = 3;
    v_record_definition = db_record_create_definition(4);

    db_record_set_definition_field(
        v_record_definition,
        0,
        db_field_create_definition("id", __NOT_NULL, __unsigned_int)
    );

    db_record_set_definition_field(
        v_record_definition,
        1,
        db_field_create_definition("brand", __NOT_NULL, __char_array)
    );

    db_record_set_definition_field(
        v_record_definition,
        2,
        db_field_create_definition("name", __NOT_NULL, __char_array)
    );

    db_record_set_definition_field(
        v_record_definition,
        3,
        db_field_create_definition("price", __NOT_NULL, __float)
    );

    /* *********************************************************
     * Create primary index
     * ********************************************************* */
    v_primary_index = db_index_create(1, __primary, NULL);

    db_index_set_field_definition(
        v_primary_index->index_fields_definition,
        0,
        db_index_create_field_definition(0, __asc));

    /* *********************************************************
     * Create the table
     * ********************************************************* */
    v_table = db_table_create(v_record_definition, v_primary_index);

    /* *********************************************************
     * Insert the records
     * ********************************************************* */
    insert(4, "BARND1", "PRODUCT4", 14);
    insert(2, "BARND1", "PRODUCT2", 125);
    insert(3, "BARND2", "PRODUCT3", 140);
    insert(1, "BARND2", "PRODUCT1", 10);

    /* *********************************************************
     * Create the indexes
     * ********************************************************* */

    /* Index 2 */
    v_index_2 = db_index_create(2, __normal, NULL);

    db_index_set_field_definition(
        v_index_2->index_fields_definition,
        0,
        db_index_create_field_definition(1, __asc));

    db_index_set_field_definition(
        v_index_2->index_fields_definition,
        1,
        db_index_create_field_definition(2, __asc));

    db_table_set_index(v_table, c_index2, v_index_2);

    /* Index 3 */
    v_index_3 = db_index_create(1, __normal, NULL);

    db_index_set_field_definition(
        v_index_3->index_fields_definition,
        0,
        db_index_create_field_definition(3, __asc));

    db_table_set_index(v_table, c_index3, v_index_3);

    /* *********************************************************
     * Create the cursors
     * ********************************************************* */
    v_cursor1 = db_cursor_create(v_table, c_index1);
    v_cursor2 = db_cursor_create(v_table, c_index2);
    v_cursor3 = db_cursor_create(v_table, c_index3);

    /* *********************************************************
     * Reports
     * ********************************************************* */
    printf("%s\n", "List 1");
    list(v_cursor1);
    printf("\n\n%s\n", "List 2");
    list(v_cursor2);
    printf("\n%s\n", "List 3");
    list(v_cursor3);

    v_key = db_cursor_create_key(v_cursor1);
    db_cursor_set_key_fields(v_key, 0, &ii);

    v_record = db_cursor_find_by_key(v_key);

    if(v_record != NULL){
        printf("\n%s\n", "Found");
        printf("%i - %s - %s - %f\n", db_field_get_unsigned_int(v_record->fields, 0),
                                      db_field_get_char_array(v_record->fields, 1),
                                      db_field_get_char_array(v_record->fields, 2),
                                      db_field_get_float(v_record->fields, 3));
    } else {
        printf("\n%s\n", "Not found");
    }

    db_cursor_drop_key(v_key);

    /* *********************************************************
     * Destroy the tables
     * ********************************************************* */
    db_cursor_drop(v_cursor1);
    db_cursor_drop(v_cursor2);
    db_cursor_drop(v_cursor3);
    db_table_drop(v_table);

    getch();

    return 0;
}




