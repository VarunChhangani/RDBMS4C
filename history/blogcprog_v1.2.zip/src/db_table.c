/* 
    blogcprog.com - db_table
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdlib.h>
#include "db_table.h"

/* ********************************************************************* 
 * typedef  : __table_for_function
 * purpose  : Event function type to provide the event function in 
 *            a FOR cicle
 * ********************************************************************* */
typedef unsigned char __table_for_function(__db_table_s_table* p_table, 
                                         __db_record_s_record* p_record, 
                                                         void* p_args[], 
                                                          long p_rownum);

/* ********************************************************************* 
 * typedef  : __p_table_for_function
 * purpose  : Pointer type for __table_for_function
 * ********************************************************************* */
typedef __table_for_function* __p_table_for_function;

__db_table_s_table* db_table_create(__db_record_s_definition* p_record_definition){
    int v_i;
    __db_table_s_table* v_table = NULL;
    if(p_record_definition != NULL){
        v_table = malloc(sizeof(__db_table_s_table));
        v_table->first_record = NULL;
        v_table->last_record = NULL;
        v_table->name = NULL;
        v_table->count = 0;
        v_table->record_definition = p_record_definition;
        for(v_i=0; v_i < 32; v_i++){
            v_table->indexes[v_i].index = NULL;
            v_table->indexes[v_i].function_based_index = NULL;
        }
        v_table->index_rebuild_needed = 1;
    }
    return v_table;
}

__db_table_s_table* db_table_create_for_structure(void){
    int v_i;
    __db_table_s_table* v_table = NULL;
    __db_record_s_definition* v_record_definition = NULL;
    v_record_definition = db_record_create_definition(1);
    db_record_set_definition_field(
                v_record_definition,
                0,
                db_field_create_definition("structure", __NOT_NULL));
    v_table = db_table_create(v_record_definition);
    return v_table;
}

unsigned char __index_creation(__db_table_s_table* p_table, 
                             __db_record_s_record* p_tablerecord, 
                                             void* p_args[], 
                                              long p_rownum){
    __db_index_index v_index;
    v_index = (__db_index_index)p_args[0];
    v_index[p_rownum] = p_tablerecord;
    return 0;
}

unsigned char __for_all(__db_table_s_table* p_table, 
                     __p_table_for_function p_table_for_function, 
                                      void* p_args[]){
    long l=0;
    unsigned char v_ret=0;
    __db_record_s_record* v_record;
    if (p_table != NULL){
        v_record = p_table->first_record;
        while(v_ret==0&&v_record!=NULL&&l<p_table->count){
            v_ret = (*p_table_for_function)(p_table, v_record, p_args, l);
            v_record = v_record->next_record;
            l++;
        }
    }
    return v_ret;
}

void __sort_index(__db_table_s_table* p_table, int p_index_position){
    long v_i, v_j;
    __db_record_s_record* v_record;
    for(v_i = (p_table->count - 1); v_i >= 0; v_i--){
        for(v_j = 1; v_j <= v_i; v_j++){
            if((*p_table->indexes[p_index_position].function_based_index)
                    (p_table->indexes[p_index_position].index[v_j - 1], 
                     p_table->indexes[p_index_position].index[v_j]) > 0){
                
                v_record = p_table->indexes[p_index_position].index[v_j - 1];
                
                p_table->indexes[p_index_position].index[v_j - 1] = 
                    p_table->indexes[p_index_position].index[v_j];
                
                p_table->indexes[p_index_position].index[v_j] = v_record;
            }
        }
    }
}

void __disable_indexes(__db_table_s_table* p_table){
    int v_i;
    long v_l;
    if (p_table != NULL){
        for(v_i = 0; v_i < 32; v_i++){
            if(p_table->indexes[v_i].function_based_index != NULL && 
               p_table->indexes[v_i].index != NULL){
                free(p_table->indexes[v_i].index);
            }
        }
        p_table->index_rebuild_needed = 1;
    }
}

void __enable_indexes(__db_table_s_table* p_table){
    int v_i;
    void* v_params[1];
    __db_index_index v_index = NULL;
    if (p_table != NULL){
        for(v_i = 0; v_i < 32; v_i++){
            if(p_table->indexes[v_i].function_based_index != NULL){
                if(p_table->indexes[v_i].index != NULL){
                    free(p_table->indexes[v_i].index);
                }
                v_index = malloc(sizeof(__db_record_s_record) * p_table->count);
                v_params[0] = v_index;
                __for_all(p_table, __index_creation, v_params);
                p_table->indexes[v_i].index = v_index;
                __sort_index(p_table, v_i);
            }
        }
        p_table->index_rebuild_needed = 0;
    }
}


__db_index_s_index db_table_create_index(__db_table_s_table* p_table, 
                                                         int p_index,
                                 __db_index_p_function_based p_function_based_index){
    __db_index_s_index v_result;
    if (p_table != NULL &&
        p_index >= 0 && 
        p_index <= 32 && 
        p_table->indexes[p_index].function_based_index == NULL &&
        p_function_based_index != NULL){
        p_table->indexes[p_index].function_based_index = p_function_based_index;
        if(p_table->indexes[p_index].index != NULL){
            free(p_table->indexes[p_index].index);
        }
        v_result = p_table->indexes[p_index];
    }
    return v_result;
}

void db_table_drop(__db_table_s_table* p_table){
    long v_l = 0;
    int v_i;
    __db_record_s_record* v_record;
    __db_record_s_record* v_record_next;
    if(p_table != NULL){
        __disable_indexes(p_table);
        v_record = p_table->first_record;
        while(v_record != NULL && v_l < p_table->count){
            v_record_next = v_record->next_record;
            if(v_record->fields != NULL){
                if(p_table->record_definition != NULL){
                    for(v_i = 0; v_i < p_table->record_definition->num_of_fields; v_i++){
                        if(v_record->fields[v_i]->field != NULL){
                            free(v_record->fields[v_i]->field);
                            free(v_record->fields[v_i]);
                        }
                    }
                }
                free(v_record->fields);
            }
            if(v_record != NULL){
                free(v_record);
            }
            v_l++;
            v_record = v_record_next;
        }
        if(p_table->record_definition != NULL){
            if(p_table->record_definition->fields_definition != NULL){
                for(v_i = 0; v_i < p_table->record_definition->num_of_fields; v_i++){
                    if(p_table->record_definition->fields_definition[v_i] != NULL){
                        free(p_table->record_definition->fields_definition[v_i]);
                    }
                }
                free(p_table->record_definition->fields_definition);
            }
            free(p_table->record_definition);
        }
        free(p_table);
    }
}    

void db_table_drop_index(__db_table_s_table* p_table, const int p_index){
    if (p_table != NULL && p_index >=0 && p_index < 32){
        if (p_table->indexes[p_index].index != NULL){
            free(p_table->indexes[p_index].index);
            p_table->indexes[p_index].index = NULL;
        }
    }
}

__db_record_s_record* db_table_insert_into(__db_table_s_table* p_table, 
                                             __db_field_fields p_fields){
    __db_record_s_record* v_record = NULL;
    if(p_table != NULL && p_fields != NULL){
        v_record = malloc(sizeof(__db_record_s_record));
        v_record->prev_record = p_table->last_record;
        v_record->next_record = NULL;
        v_record->fields = p_fields;
        p_table->count++;
        if(p_table->index_rebuild_needed == 0){
            __disable_indexes(p_table);
        }
        if(p_table->last_record!=NULL){
            p_table->last_record->next_record = v_record;
        }
        p_table->last_record = v_record;
        if(p_table->first_record == NULL) 
            p_table->first_record = v_record;
    }
    return v_record;
}

__db_record_s_record* db_table_insert_structure_into(__db_table_s_table* p_table, 
                                                                   void* p_structure){
    __db_record_s_record* v_record = NULL;
    __db_field_fields v_fields;
    v_fields = db_field_create(1);
    db_field_set_value(v_fields, 0, p_structure);
    v_record = db_table_insert_into(p_table, v_fields);
    return v_record;
}

void db_table_delete_from(__db_table_s_table* p_table, 
                                    const int p_index,
                               const long int p_position){
    __db_record_s_record* v_se = db_table_get_record(p_table, p_index, p_position);
    if(v_se != NULL){
        if(p_position == 0){
            p_table->first_record = v_se->next_record;
            if(v_se->next_record != NULL){
                v_se->next_record->prev_record = NULL;
            }
        } else {
            if(v_se->prev_record != NULL){
                v_se->prev_record->next_record = v_se->next_record;
            }
        }
        free(v_se->fields);
        free(v_se);
        p_table->count--;
        if(p_table->index_rebuild_needed == 0){
            __disable_indexes(p_table);
        }
    }
}

__db_record_s_record* db_table_get_record(__db_table_s_table* p_table, 
                                                    const int p_index, 
                                               const long int p_position){
    long int v_l=0;
    __db_record_s_record* v_result = NULL;
    __db_index_index v_index;
    if (p_table != NULL){ 
        if (p_table->index_rebuild_needed != 0){
            __enable_indexes(p_table);
        }
        if (p_position > -1 && 
            p_position < p_table->count &&
            p_index >= 0 &&
            p_index < 32 &&
            p_table->indexes[p_index].index != NULL){
            v_index = p_table->indexes[p_index].index;
            v_result = v_index[p_position];
        }
    }
    return v_result;
}

