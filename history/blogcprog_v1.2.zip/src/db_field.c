/* 
    blogcprog.com - db_field
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdlib.h>
#include "db_field.h"


__db_field_s_field_definition* db_field_create_definition(
             __db_general_name p_name, 
    __db_field_NULL_definition p_NULL_definition){
    __db_field_s_field_definition* v_result = NULL;
    if(p_name != NULL && p_NULL_definition){
        v_result = malloc(sizeof(__db_field_s_field_definition));
        v_result->name = p_name;
        v_result->null_definition = p_NULL_definition;
    }
    return v_result;
}

__db_field_fields db_field_create(int p_num_of_fields){
    __db_field_fields v_result = NULL;
    int v_i;
    if(p_num_of_fields > 0){
        v_result = malloc(sizeof(__db_field_s_field*) * p_num_of_fields);
        for(v_i = 0; v_i < p_num_of_fields; v_i++){
            v_result[v_i] = NULL;
        }
    }
    return v_result;
}

void db_field_set_value(__db_field_fields p_fields, 
                                      int p_position, 
                                    void* p_value){
    __db_field_s_field* v_field;
    if(p_fields != NULL && p_position >= 0){
        if(p_fields[p_position] != NULL){
            if(p_fields[p_position]->field != NULL){
                free(p_fields[p_position]->field);
            }
            free(p_fields[p_position]);
        }
        v_field = malloc(sizeof(__db_field_s_field));
        v_field->field = p_value;
        p_fields[p_position] = v_field;
    }
}


