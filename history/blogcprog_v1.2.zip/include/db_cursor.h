/* 
    blogcprog.com - db_cursor
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __DB_CURSOR__
#define __DB_CURSOR__

/* ********************************************************************* 
 * file     : db_cursor
 * purpose  : Cursor
 *
 * status   : under construction 
 *
 * ********************************************************************* */

#include "db.h"

/* -------------------------------------------------- * 
 * --------------- Type definitions ----------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * typedef  : __db_cursor_for_function
 * purpose  : Event function type to provide the event function 
 *            in a FOR cycle
 * ********************************************************************* */
typedef unsigned char __db_cursor_for_function(__db_table_s_table* p_table, 
                                             __db_record_s_record* p_record, 
                                                             void* p_args[], 
                                                              long p_rownum);

/* ********************************************************************* 
 * typedef  : __db_cursor_p_for_function
 * purpose  : Pointer type for __db_cursor_for_function
 * ********************************************************************* */
typedef __db_cursor_for_function* __db_cursor_p_for_function;

/* ********************************************************************* 
 * typedef  : __db_cursor_s_cursor
 * purpose  : Cursor for a table 
 * ********************************************************************* */
typedef struct __db_cursor_ss_cursor {
    __db_table_s_table* table;
    int index_position;
    long current;
} __db_cursor_s_cursor;

/* -------------------------------------------------- * 
 * ----------- End of the Type definitions ---------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- * 
 * ------------------- Functions -------------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * function : db_cursor_create
 * purpose  : Create index based cursor for p_table
 * ********************************************************************* */
__db_cursor_s_cursor* db_cursor_create(__db_table_s_table* p_table,
                                                       int p_index_position);

/* ********************************************************************* 
 * function : db_cursor_drop
 * purpose  : Drop cursor 
 * ********************************************************************* */
void db_cursor_drop(__db_cursor_s_cursor* p_cursor);

/* ********************************************************************* 
 * function : db_cursor_current
 * purpose  : Get current __srecord* from the cursor 
 * ********************************************************************* */
__db_record_s_record* db_cursor_current(__db_cursor_s_cursor* p_cursor);

/* ********************************************************************* 
 * function : db_cursor_next
 * purpose  : Get next __srecord* from the cursor 
 * ********************************************************************* */
__db_record_s_record* db_cursor_next(__db_cursor_s_cursor* p_cursor);

/* ********************************************************************* 
 * function : db_cursor_prev
 * purpose  : Get previous __srecord* from the cursor 
 * ********************************************************************* */
__db_record_s_record* db_cursor_prev(__db_cursor_s_cursor* p_cursor);

/* ********************************************************************* 
 * function : db_cursor_first
 * purpose  : Get first __srecord* from the cursor 
 * ********************************************************************* */
__db_record_s_record* db_cursor_first(__db_cursor_s_cursor* p_cursor);

/* ********************************************************************* 
 * function : db_cursor_last
 * purpose  : Get last __srecord* from the cursor 
 * ********************************************************************* */
__db_record_s_record* db_cursor_last(__db_cursor_s_cursor* p_cursor);

/* ********************************************************************* 
 * function : db_cursor_for_all
 * purpose  : loop statement on the p_cursor's records 
 * ********************************************************************* */
unsigned char db_cursor_for_all(__db_cursor_s_cursor* p_cursor, 
                           __db_cursor_p_for_function p_cursor_for_function, 
                                                void* p_args[]);

/* -------------------------------------------------- * 
 * --------------- End of the Functions ------------- *
 * -------------------------------------------------- * */

#endif
