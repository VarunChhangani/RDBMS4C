/* 
    blogcprog.com - db_record
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __DB_RECORD__
#define __DB_RECORD__

/* ********************************************************************* 
 * file     : db
 * purpose  : 
 *
 * ********************************************************************* */

#include "db_general.h"
#include "db_field.h"

/* -------------------------------------------------- * 
 * --------------- Type definitions ----------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * typedef  : __db_record_s_definition
 * purpose  : Record definition for table 
 * ********************************************************************* */
typedef struct __db_record_ss_definition {
    __fields_definition fields_definition;
    int num_of_fields;
} __db_record_s_definition;

/* ********************************************************************* 
 * typedef  : __db_record_s_record
 * purpose  : Record type in the table including record chain 
 * ********************************************************************* */
typedef struct __db_record_ss_record {
    __db_field_fields fields;
    struct __db_record_ss_record* prev_record;
    struct __db_record_ss_record* next_record;
} __db_record_s_record;

/* -------------------------------------------------- * 
 * ----------- End of the Type definitions ---------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- * 
 * ------------------- Functions -------------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * function : db_record_create_definition
 * purpose  : Create record definition with p_num_of_fields
 * ********************************************************************* */
__db_record_s_definition* db_record_create_definition(int p_num_of_fields);

/* ********************************************************************* 
 * function : db_record_set_definition_field
 * purpose  : Set field definition in record definition 
 * ********************************************************************* */
void db_record_set_definition_field(__db_record_s_definition* p_record_definition, 
                                                          int p_position, 
                               __db_field_s_field_definition* p_field_definition);

/* -------------------------------------------------- * 
 * --------------- End of the Functions ------------- *
 * -------------------------------------------------- * */

#endif
