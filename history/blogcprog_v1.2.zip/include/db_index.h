/* 
    blogcprog.com - db_index
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __DB_INDEX__
#define __DB_INDEX__

/* ********************************************************************* 
 * file     : db_index
 * purpose  : 
 *
 * ********************************************************************* */

#include "db_record.h"

/* -------------------------------------------------- * 
 * --------------- Type definitions ----------------- *
 * -------------------------------------------------- * */


/* ********************************************************************* 
 * typedef  : __db_index_index_type
 * purpose  : Index type
 * note     : for future usage 
 * ********************************************************************* */
typedef enum {__normal = 0, __primary = 1, __unique = 2} __db_index_index_type;

/* ********************************************************************* 
 * typedef  : __db_index_index
 * purpose  : Index base type 
 * ********************************************************************* */
typedef __db_record_s_record** __db_index_index;

/* ********************************************************************* 
 * typedef  : __db_index_function_based
 * purpose  : Function type for indexes, return with 1 if the p_record_1
 *            is greater than the p_record_2. 
 * ********************************************************************* */
typedef int __db_index_function_based(const __db_record_s_record* p_record_1, 
                                      const __db_record_s_record* p_record_2);

/* ********************************************************************* 
 * typedef  : __db_index_p_function_based
 * purpose  : Pointer type for __db_index_function_based
 * ********************************************************************* */
typedef __db_index_function_based* __db_index_p_function_based;

/* ********************************************************************* 
 * typedef  : __db_index_s_index
 * purpose  : Index storage
 * ********************************************************************* */
typedef struct __db_index_ss_index {
    __db_index_index index;
    __db_index_p_function_based function_based_index;
} __db_index_s_index;

/* -------------------------------------------------- * 
 * ----------- End of the Type definitions ---------- *
 * -------------------------------------------------- * */

#endif
