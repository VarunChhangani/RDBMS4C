/*
    blogcprog.com - How to use the blogcprog.com C functions
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "db.h"

db_t_rec_def v_rec_def;
db_t_fld v_fld;
db_t_idx v_pk;
db_t_idx v_idx_2;
db_t_idx v_idx_3;
db_t_tab v_tab;
db_t_cur v_cur1;
db_t_cur v_cur2;
db_t_cur v_cur3;
db_t_key v_key;
db_t_rec v_rec;

void insert(unsigned int p_id, char* p_brand, char* p_name, float p_price){
    v_fld = db_ins_pre(4);
    db_ins_set_fld(v_rec_def, v_fld, 0, &p_id);
    db_ins_set_fld(v_rec_def, v_fld, 1, p_brand);
    db_ins_set_fld(v_rec_def, v_fld, 2, p_name);
    db_ins_set_fld(v_rec_def, v_fld, 3, &p_price);
    db_ins_exe(v_tab, v_fld);
}

void list(__db_cursor_s_cursor* p_cursor){
    v_rec = db_cursor_first(p_cursor);
    do {
        if(v_rec != NULL){
            printf("%i - %s - %s - %f\n",
                db_get_f_uns_int(v_rec, 0),
                db_get_f_cha_arr(v_rec, 1),
                db_get_f_cha_arr(v_rec, 2),
                db_get_f_flo(v_rec, 3)
            );
        }
    } while ((v_rec = db_cursor_next(p_cursor)) != NULL);
}

int main(int argc, char *argv[]){
    int ii = 3;
    float v_f;

    v_rec_def = db_cre_rec_def(4);
    db_set_rec_def_fld(v_rec_def, 0, "id", __NOT_NULL, __unsigned_int);
    db_set_rec_def_fld(v_rec_def, 1, "brand", __NOT_NULL, __char_array);
    db_set_rec_def_fld(v_rec_def, 2, "name", __NOT_NULL, __char_array);
    db_set_rec_def_fld(v_rec_def, 3, "price", __NOT_NULL, __float);
    v_pk = db_cre_pk(1);
    db_set_idx_fld(v_pk, 0, 0, __asc);
    v_tab = db_cre_tab(v_rec_def, v_pk);

    insert(4, "BARND3", "PRODUCT4", 24);
    insert(5, "BARND1", "PRODUCT5", 14);
    insert(2, "BARND1", "PRODUCT2", 125);
    insert(3, "BARND2", "PRODUCT3", 140);
    insert(1, "BARND2", "PRODUCT1", 10);

    v_idx_2 = db_cre_idx(2, __normal);
    db_set_idx_fld(v_idx_2, 0, 1, __asc);
    db_set_idx_fld(v_idx_2, 1, 2, __asc);
    db_set_tab_idx(v_tab, 1, v_idx_2);

    v_idx_3 = db_cre_idx(1, __normal);
    db_set_idx_fld(v_idx_3, 0, 3, __asc);
    db_set_tab_idx(v_tab, 2, v_idx_3);

    v_cur1 = db_cre_cur(v_tab, 0);
    v_cur2 = db_cre_cur(v_tab, 1);
    v_cur3 = db_cre_cur(v_tab, 2);

    printf("%s\n", "List 1");
    list(v_cur1);
    printf("\n\n%s\n", "List 2");
    list(v_cur2);
    printf("\n%s\n", "List 3");
    list(v_cur3);

    v_key = db_cre_key(v_cur1);
    db_set_key_fld(v_key, 0, &ii);
    v_rec = db_fnd_by_key(v_key);

    if(v_rec != NULL){
        v_f = 1245;
        db_upd(v_key->cursor, 3, &v_f);
        printf("\n%s\n", "Found");
        printf("%i - %s - %s - %f\n",
                db_get_f_uns_int(v_rec, 0),
                db_get_f_cha_arr(v_rec, 1),
                db_get_f_cha_arr(v_rec, 2),
                db_get_f_flo(v_rec, 3)
        );
    } else {
        printf("\n%s\n", "Not found");
    }

    db_drp_key(v_key);
    db_drp_cur(v_cur1);
    db_drp_cur(v_cur2);
    db_drp_cur(v_cur3);
    db_drp_tab(v_tab);

    getch();

    return 0;
}
