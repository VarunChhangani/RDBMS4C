/*
    blogcprog.com - db_index
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "db_index.h"


__db_index_s_index_field_definition* db_index_create_field_definition(
                           int p_field_index,
    __db_index_field_sort_type p_field_sort_type){
    __db_index_s_index_field_definition* v_result = NULL;
    v_result = malloc(sizeof(__db_index_s_index_field_definition));
    v_result->field_index = p_field_index;
    v_result->sort_type = p_field_sort_type;
    return v_result;
}

__db_index_s_index* db_index_create(int p_num_of_index_fields,
                  __db_index_index_type p_index_type,
            __db_index_p_function_based p_f){
    __db_index_s_index* v_result = NULL;
    int v_i;
    if(p_num_of_index_fields > 0) {
        v_result = malloc(sizeof(__db_index_s_index));
        v_result->function_based_index = p_f;
        v_result->index_type = p_index_type;
        v_result->index = NULL;
        v_result->index_rebuild_needed = 1;
        v_result->index_fields_definition = malloc(
            sizeof(__db_index_s_index_field_definition*) * p_num_of_index_fields);
        for(v_i = 0; v_i < p_num_of_index_fields; v_i++){
            v_result->index_fields_definition[v_i] = NULL;
        }
        v_result->num_of_index_fields = p_num_of_index_fields;
    }
    return v_result;
}

void db_index_set_field_definition(
              __index_fields_definition* p_index_fields_definition,
                                     int p_position,
    __db_index_s_index_field_definition* p_index_field_definition){
    if(p_index_fields_definition != NULL &&
       p_position >= 0 &&
       p_index_field_definition != NULL){
        p_index_fields_definition[p_position] = p_index_field_definition;
    }
}

