/*
    blogcprog.com - db_field
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdlib.h>
#include "db_field.h"


__db_field_s_field_definition* db_field_create_definition(
             __db_general_name p_name,
    __db_field_NULL_definition p_NULL_definition,
          __db_field_data_type p_data_type){
    __db_field_s_field_definition* v_result = NULL;
    if(p_name != NULL &&
       p_NULL_definition >= 0 &&
       p_NULL_definition <= 1 &&
       p_data_type >= 0){
        v_result = malloc(sizeof(__db_field_s_field_definition));
        v_result->name = p_name;
        v_result->data_type = p_data_type;
        v_result->null_definition = p_NULL_definition;
    }
    return v_result;
}

__db_field_fields db_field_create(int p_num_of_fields){
    __db_field_fields v_result = NULL;
    int v_i;
    if(p_num_of_fields > 0){
        v_result = malloc(sizeof(__db_field_s_field*) * p_num_of_fields);
        for(v_i = 0; v_i < p_num_of_fields; v_i++){
            v_result[v_i] = NULL;
        }
    }
    return v_result;
}

void db_field_drop(__db_field_fields p_fields,
                                 int p_num_of_fields){
    int v_i;
    if(p_fields != NULL){
        for(v_i = 0; v_i < p_num_of_fields; v_i++){
            if(p_fields[v_i] != NULL){
                if(p_fields[v_i]->field != NULL){
                    free(p_fields[v_i]->field);
                }
                free(p_fields[v_i]);
            }
        }
        free(p_fields);
    }
}

void db_field_set_value(__fields_definition p_fields_definition,
                          __db_field_fields p_fields,
                  const __db_field_position p_position,
                                const void* p_value){
    __db_field_s_field* v_field;
    db_error_reset();
    if(p_fields_definition != NULL && p_fields != NULL && p_position >= 0){
        if(p_fields_definition[p_position]->null_definition == __NULL ||
           p_value != NULL){
            if(p_fields[p_position] != NULL){
                if(p_fields[p_position]->field != NULL){
                    free(p_fields[p_position]->field);
                }
                free(p_fields[p_position]);
            }
            v_field = malloc(sizeof(__db_field_s_field));
            if(p_value != NULL) {
                switch (p_fields_definition[p_position]->data_type) {
                    case __char_array:
                        v_field->field = malloc((sizeof(char) *
                                                 strlen((char*)p_value)) + 1);
                        strcpy((char*)v_field->field, (char*)p_value);
                    break;
                    case __char:
                        v_field->field = malloc(sizeof(char));
                        *(char*)v_field->field = *(char*)p_value;
                    break;
                    case __unsigned_char:
                        v_field->field = malloc(sizeof(unsigned char));
                        *(unsigned char*)v_field->field = *(unsigned char*)p_value;
                    break;
                    case __int:
                        v_field->field = malloc(sizeof(int));
                        *(int*)v_field->field = *(int*)p_value;
                    break;
                    case __unsigned_int:
                        v_field->field = malloc(sizeof(unsigned int));
                        *(unsigned int*)v_field->field = *(unsigned int*)p_value;
                    break;
                    case __long:
                        v_field->field = malloc(sizeof(long));
                        *(long*)v_field->field = *(long*)p_value;
                    break;
                    case __unsigned_long:
                        v_field->field = malloc(sizeof(unsigned long));
                        *(unsigned long*)v_field->field = *(unsigned long*)p_value;
                    break;
                    case __float:
                        v_field->field = malloc(sizeof(float));
                        *(float*)v_field->field = *(float*)p_value;
                    break;
                    case __double:
                        v_field->field = malloc(sizeof(double));
                        *(double*)v_field->field = *(double*)p_value;
                    break;
                    case __void_pointer:
                        v_field->field = p_value;
                    break;

                    default:
                        v_field->field = p_value;
                    break;
                }
            } else {
                v_field->field = NULL;
            }
            p_fields[p_position] = v_field;
        } else {
            db_error_set_error(__EMPTY_MANDATORY_FIELD);
        }
    } else {
        db_error_set_error(__NOT_NULL_VIOLATION);
    }
}

unsigned char db_field_is_filled(__db_field_fields p_fields,
                         const __db_field_position p_position){
    unsigned char  v_result = 0;
    if(p_fields != NULL &&
       p_position >=0 &&
       p_fields[p_position] != NULL &&
       p_fields[p_position]->field != NULL){
       v_result = 1;
    }
    return v_result;
}

const char db_field_get_char(__db_field_fields p_fields,
                     const __db_field_position p_position){
    char  v_result = 0;
    if(db_field_is_filled(p_fields, p_position)){
       v_result = *(char *)p_fields[p_position]->field;
    }
    return v_result;
}

const unsigned char db_field_get_unsigned_char(__db_field_fields p_fields,
                                       const __db_field_position p_position){
    unsigned char  v_result = 0;
    if(db_field_is_filled(p_fields, p_position)){
       v_result = *(unsigned char *)p_fields[p_position]->field;
    }
    return v_result;
}

const int db_field_get_int(__db_field_fields p_fields,
                   const __db_field_position p_position){
    int v_result = 0;
    if(db_field_is_filled(p_fields, p_position)){
       v_result = *(int*)p_fields[p_position]->field;
    }
    return v_result;
}

const unsigned int db_field_get_unsigned_int(__db_field_fields p_fields,
                                     const __db_field_position p_position){
    unsigned int v_result = 0;
    if(db_field_is_filled(p_fields, p_position)){
       v_result = *(unsigned int*)p_fields[p_position]->field;
    }
    return v_result;
}

const long db_field_get_long(__db_field_fields p_fields,
                     const __db_field_position p_position){
    long v_result = 0;
    if(db_field_is_filled(p_fields, p_position)){
       v_result = *(long*)p_fields[p_position]->field;
    }
    return v_result;
}

const unsigned long db_field_get_unsigned_long(__db_field_fields p_fields,
                                       const __db_field_position p_position){
    unsigned long v_result = 0;
    if(db_field_is_filled(p_fields, p_position)){
       v_result = *(unsigned long*)p_fields[p_position]->field;
    }
    return v_result;
}

const float db_field_get_float(__db_field_fields p_fields,
                       const __db_field_position p_position){
    float v_result = 0;
    if(db_field_is_filled(p_fields, p_position)){
       v_result = *(float*)p_fields[p_position]->field;
    }
    return v_result;
}

const double db_field_get_double(__db_field_fields p_fields,
                         const __db_field_position p_position){
    double v_result = 0;
    if(db_field_is_filled(p_fields, p_position)){
       v_result = *(double*)p_fields[p_position]->field;
    }
    return v_result;
}

const void* db_field_get_void(__db_field_fields p_fields,
                      const __db_field_position p_position){
    void* v_result = 0;
    if(db_field_is_filled(p_fields, p_position)){
       v_result = p_fields[p_position]->field;
    }
    return v_result;
}

const char* db_field_get_char_array(__db_field_fields p_fields,
                            const __db_field_position p_position){
    char* v_result = 0;
    if(db_field_is_filled(p_fields, p_position)){
       v_result = (char*)p_fields[p_position]->field;
    }
    return v_result;
}

