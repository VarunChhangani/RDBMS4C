/* 
    blogcprog.com - DB
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdlib.h>
#include "db.h"

__srecord_definition* db$create_record_definition(int p_num_of_fields){
    __srecord_definition* v_result = NULL;
    __fields_definition v_fields_definition = NULL;
    if (p_num_of_fields > 0){
        v_result = malloc(sizeof(__srecord_definition));
        v_fields_definition = malloc(sizeof(__fields_definition) * p_num_of_fields);
        v_result->fields_definition = v_fields_definition;
        v_result->num_of_fields = p_num_of_fields;
    }
    return v_result;
}

__sfield_definition* db$create_field_definition(__data_type p_data_type, 
                                                     __name p_name, 
                                                     __NULL_definition p_NULL_definition){
    __sfield_definition* v_result = NULL;
    if(p_data_type != NULL && p_name != NULL && p_NULL_definition){
        v_result = malloc(sizeof(__sfield_definition));
        v_result->data_type = p_data_type;
        v_result->name = p_name;
        v_result->null_definition = p_NULL_definition;
    }
    return v_result;
}

void db$set_record_definition_field(__srecord_definition* p_record_definition,
                                                      int p_position, 
                                                      __sfield_definition* p_field_definition){
    if (p_record_definition != NULL && 
        p_position >= 0 &&
        p_position < p_record_definition->num_of_fields &&
        p_field_definition != NULL &&
        p_record_definition->fields_definition != NULL){
            if(p_record_definition->fields_definition[p_position] != NULL){
                free(p_record_definition->fields_definition[p_position]);
            }
            p_record_definition->fields_definition[p_position] = p_field_definition;
    }
}

__stable* db$create_table(__srecord_definition* p_record_definition){
    int v_i;
    __stable* v_table = NULL;
    if(p_record_definition != NULL){
        v_table = malloc(sizeof(__stable));
        v_table->first_record = NULL;
        v_table->last_record = NULL;
        v_table->name = NULL;
	    v_table->count = 0;
        v_table->record_definition = p_record_definition;
        for(v_i=0; v_i < 32; v_i++){
            v_table->indexes[v_i].index = NULL;
            v_table->indexes[v_i].index_definition = NULL;
        }
    }
    return v_table;
}

unsigned char __index_creation(__stable* p_table, 
                              __srecord* p_tablerecord, 
                                   void* p_args[], 
                                    long p_rownum){
    __index v_index;
    v_index = (__index)p_args[0];
    v_index[p_rownum] = p_tablerecord;
    return 0;
}

__sindex db$create_index(__stable* p_table, int p_index){
    void* v_params[1];
    __sindex v_result;
    __index v_index = NULL;
    if (p_table != NULL &&
        p_index >= 0 && 
        p_index <= 32 && 
        p_table->indexes[p_index].index == NULL){
        v_index = malloc(sizeof(__srecord) * p_table->count);
        v_params[0] = v_index;
        db$for_all(p_table, __index_creation, v_params);
        p_table->indexes[p_index].index = v_index;
        v_result = p_table->indexes[p_index];
    }
    return v_result;
}

void db$drop_table(__stable* p_table){
    long v_l = 0;
    int v_i;
    __srecord* v_memlistrecord;
    __srecord* v_memlistrecord_prev;
    if(p_table != NULL){
        for(v_i=0; v_i<32; v_i++){
            free(p_table->indexes[v_i].index);
        }
        v_memlistrecord = p_table->first_record;
        while(v_memlistrecord != NULL && v_l < p_table->count){
            v_memlistrecord_prev = v_memlistrecord;
            v_memlistrecord = v_memlistrecord->next_record;
            free(v_memlistrecord_prev->fields);
            free(v_memlistrecord_prev);
            v_l++;
        }
        free(p_table);
    }
}    

void db$drop_index(__stable* p_table, const int p_index){
    if (p_table != NULL && p_index >=0 && p_index < 32){
        if (p_table->indexes[p_index].index != NULL){
            free(p_table->indexes[p_index].index);
            p_table->indexes[p_index].index = NULL;
            p_table->indexes[p_index].index_definition = NULL;
        }
    }
}

__fields db$create_fields(int p_num_of_fields){
    __fields v_result = NULL;
    int v_i;
    if(p_num_of_fields > 0){
        v_result = malloc(sizeof(__fields) * p_num_of_fields);
        for(v_i = 0; v_i < p_num_of_fields; v_i++){
            v_result[v_i] = NULL;
        }
    }
    return v_result;
}

void db$set_field_value(__fields p_fields, 
                             int p_position, 
                           void* p_value){
    __sfield* v_field;
    if(p_fields != NULL && p_position >= 0){
        if(p_fields[p_position] != NULL){
            if(p_fields[p_position]->field != NULL){
                free(p_fields[p_position]->field);
            }
            free(p_fields[p_position]);
        }
        v_field = malloc(sizeof(__sfield));
        v_field->field = p_value;
        p_fields[p_position] = v_field;
    }
}

__srecord* db$insert_into(__stable* p_table, __fields p_fields){
    __srecord* v_record = NULL;
    if(p_table != NULL && p_fields != NULL){
        v_record = malloc(sizeof(__srecord));
        v_record->prev_record = p_table->last_record;
        v_record->next_record = NULL;
        v_record->fields = p_fields;
        p_table->count++;
        if(p_table->last_record!=NULL){
            p_table->last_record->next_record = v_record;
        }
        p_table->last_record = v_record;
        if(p_table->first_record == NULL) 
            p_table->first_record = v_record;
    }
    return v_record;
}

unsigned char db$for_all(__stable* p_table, 
            __p_table_for_function p_table_for_function, 
                             void* p_args[]){
    long l=0;
    unsigned char v_ret=0;
    __srecord* v_record;
    v_record = p_table->first_record;
	while(v_ret==0&&v_record!=NULL&&l<p_table->count){
        v_ret = (*p_table_for_function)(p_table, v_record, p_args, l);
        v_record = v_record->next_record;
        l++;
    }
    return v_ret;
}

unsigned char db$for_all_by_index(__stable* p_table, 
                                        int p_index,
                     __p_table_for_function p_table_for_function, 
                                      void* p_args[]){
    long l=0;
    unsigned char v_ret=0;
	while(v_ret==0 && l < p_table->count){
        v_ret = (*p_table_for_function)(p_table, db$get_record(p_table, p_index, l), p_args, l);
        l++;
    }
    return v_ret;
}
__srecord* db$get_record(__stable* p_table, 
                         const int p_index, 
                    const long int p_position){
    long int v_l=0;
    __srecord* v_result = NULL;
    __index v_index;
    if(p_table != NULL && 
       p_position > -1 && 
       p_position < p_table->count &&
       p_index >= 0 &&
       p_index < 32 &&
       p_table->indexes[p_index].index != NULL){
        v_index = p_table->indexes[p_index].index;
        v_result = v_index[p_position];
    }
    return v_result;
}

void db$delete_from(__stable* p_table, 
                    const int p_index,
               const long int p_position){
    __srecord* v_se = db$get_record(p_table, p_index, p_position);
    if(v_se != NULL){
        if(p_position == 0){
            p_table->first_record = v_se->next_record;
            if(v_se->next_record != NULL){
                v_se->next_record->prev_record = NULL;
            }
        } else {
            if(v_se->prev_record != NULL){
                v_se->prev_record->next_record = v_se->next_record;
            }
        }
        free(v_se->fields);
        free(v_se);
        p_table->count--;
    }
}

