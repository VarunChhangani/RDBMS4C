/* 
    blogcprog.com - DB
    Copyright (C) 2010  blogcprog.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __DB__
#define __DB__

/* ********************************************************************* 
 * file     : db
 * purpose  : This db solution is to provide an easy and usable 
 *            dynamic memory handling API for C developers, 
 *            containing all of the well known solutions in this theme,
 *            so the SQL design as solution is more than welcome during 
 *            the developing.
 *
 * example  : #include "db.h"
 *            ...
 *            __srecord_definition* v_record_definition;
 *            __stable* v_table;
 *            __fields v_fields;
 *            ...
 *            v_record_definition = db$create_record_definition(3);
 *
 *            db$set_record_definition_field(
 *                v_record_definition, 
 *                0, 
 *                db$create_field_definition(__int, "ID", __NOT_NULL));
 *
 *            db$set_record_definition_field(
 *                v_record_definition, 
 *                1, 
 *                db$create_field_definition(__char, "NAME", __NOT_NULL));
 *
 *            db$set_record_definition_field(
 *                v_record_definition, 
 *                2, 
 *                db$create_field_definition(__char, "MOBILE_PHONE", __NOT_NULL));
 *
 *            v_table = db$create_table(v_record_definition);
 *            
 *            ...
 *
 *            v_fields = db$create_fields(3);
 *
 *            db$set_field_value(v_fields, 0, v_int_value);
 *            db$set_field_value(v_fields, 1, v_name);
 *            db$set_field_value(v_fields, 2, v_mobile_phone);
 *
 *            db$insert_into(v_table, v_fields);
 * 
 *            ...
 *
 *            printf("%s", db$get_record(v_table, 0, 0)->fields[1]->field);
 *
 *            ...
 *            db$drop_table(v_table);
 *
 * status   : under construction 
 * next     : index usage based on fields, check constraints, etc...
 * far      : Additional database functions...
 *
 * ********************************************************************* */

/* -------------------------------------------------- * 
 * --------------- Type definitions ----------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * typedef  : __name_array
 * purpose  : Name array type for general object names 
 * ********************************************************************* */
typedef char __name_array[32];

/* ********************************************************************* 
 * typedef  : __name
 * purpose  : Name type for general object names 
 * ********************************************************************* */
typedef __name_array* __name;

/* ********************************************************************* 
 * typedef  : __data_type
 * purpose  : C related data types for DB fields 
 * ********************************************************************* */
typedef enum {__char = 0, __int = 1, __long = 2} __data_type;

/* ********************************************************************* 
 * typedef  : __NULL_definition
 * purpose  : NULL definition for DB fields
 * ********************************************************************* */
typedef enum {__NULL = 0, __NOT_NULL = 1} __NULL_definition;

/* ********************************************************************* 
 * typedef  : __sfield_definition
 * purpose  : Field definition
 * ********************************************************************* */
typedef struct ssfield_definition {
    __name name;
    __data_type data_type;
    __NULL_definition null_definition;
} __sfield_definition;

/* ********************************************************************* 
 * typedef  : __fields_definition
 * purpose  : Fields definition for record 
 * ********************************************************************* */
typedef __sfield_definition** __fields_definition;

/* ********************************************************************* 
 * typedef  : __srecord_definition
 * purpose  : Record definition for table 
 * ********************************************************************* */
typedef struct ssrecord_definition {
    __fields_definition fields_definition;
    int num_of_fields;
} __srecord_definition;

/* ********************************************************************* 
 * typedef  : __sfield
 * purpose  : Field to store a value 
 * ********************************************************************* */
typedef struct ssfield {
    void* field;
} __sfield;

/* ********************************************************************* 
 * typedef  : __fields
 * purpose  : Fields type for a DB record 
 * ********************************************************************* */
typedef __sfield** __fields;

/* ********************************************************************* 
 * typedef  : __srecord
 * purpose  : Record type in the table including record chain 
 * ********************************************************************* */
typedef struct ssrecord {
    __fields fields;
    struct ssrecord* prev_record;
    struct ssrecord* next_record;
} __srecord;

/* ********************************************************************* 
 * typedef  : __index_type
 * purpose  : Index type
 * note     : for future usage 
 * ********************************************************************* */
typedef enum {__normal = 0, __primary = 1, __unique = 2} __index_type;

/* ********************************************************************* 
 * typedef  : __sindex_definition
 * purpose  : Index definition 
 * note     : for future usage 
 * ********************************************************************* */
typedef struct __sindex_definition {
    int** field_positions;
    int num_of_fields;
    __index_type index_type;
} __sindex_definition;

/* ********************************************************************* 
 * typedef  : __sindex
 * purpose  : Index base type 
 * ********************************************************************* */
typedef __srecord** __index;

/* ********************************************************************* 
 * typedef  : __sindex
 * purpose  : Index storage
 * ********************************************************************* */
typedef struct ssindex {
    __index index;
    __sindex_definition* index_definition;
} __sindex;

/* ********************************************************************* 
 * typedef  : __stable
 * purpose  : Table base structure 
 * ********************************************************************* */
typedef struct sstable {
    __name name;
    __srecord* first_record;
    __srecord* last_record;
    __srecord_definition* record_definition;
    __sindex indexes[32];
    long count;
} __stable;

/* ********************************************************************* 
 * typedef  : __table_for_function
 * purpose  : Event function type to provide the event function in a FOR cycle 
 * ********************************************************************* */
typedef unsigned char __table_for_function(__stable* p_table, 
                                          __srecord* p_record, 
                                               void* p_args[], 
                                                long p_rownum);

/* ********************************************************************* 
 * typedef  : __p_table_for_function
 * purpose  : Pointer type for __table_for_function
 * ********************************************************************* */
typedef __table_for_function* __p_table_for_function;

/* -------------------------------------------------- * 
 * ----------- End of the Type definitions ---------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- * 
 * ------------------- Functions -------------------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- * 
 * ------------------- DDL design ------------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * function : db$create_record_definition
 * purpose  : Create record definition
 * ********************************************************************* */
__srecord_definition* db$create_record_definition(int p_num_of_fields);

/* ********************************************************************* 
 * function : db$create_field_definition
 * purpose  : Create field definition 
 * ********************************************************************* */
__sfield_definition* db$create_field_definition(__data_type p_data_type, 
                                                     __name p_name, 
                                          __NULL_definition p_NULL_definition);

/* ********************************************************************* 
 * function : db$set_record_definition_field
 * purpose  : Set field definition in record definition 
 * ********************************************************************* */
void db$set_record_definition_field(__srecord_definition* p_record_definition, 
                                                      int p_position, 
                                     __sfield_definition* p_field_definition);

/* ********************************************************************* 
 * function : db$create_table
 * purpose  : Create table
 * ********************************************************************* */
__stable* db$create_table(__srecord_definition* p_record_definition);

/* ********************************************************************* 
 * function : db$create_index
 * purpose  : Create index at the p_index position in the p_table
 * ********************************************************************* */
__sindex db$create_index(__stable* p_table, int p_index);

/* ********************************************************************* 
 * function : db$drop_table
 * purpose  : Drop table. 
 *            Please note, that it works only when the calling of the "free" 
 *            function is possible on all of the inserted data in the table.
 * ********************************************************************* */
void db$drop_table(__stable* p_table);

/* ********************************************************************* 
 * function : db$drop_index
 * purpose  : Drop the p_index in the p_memlist. 
 * ********************************************************************* */
void db$drop_index(__stable* p_table, const int p_index);

/* -------------------------------------------------- * 
 * -------------- End of the DDL design ------------- *
 * -------------------------------------------------- * */

/* -------------------------------------------------- * 
 * ------------------- DML design ------------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * function : db$create_fields
 * purpose  : Create fields 
 * ********************************************************************* */
__fields db$create_fields(int p_num_of_fields);

/* ********************************************************************* 
 * function : db$set_field_value
 * purpose  : Set field value
 * ********************************************************************* */
void db$set_field_value(__fields p_fields, 
                             int p_position, 
                           void* p_value);

/* ********************************************************************* 
 * function : db$insert_into
 * purpose  : Put record to the end of the p_table
 * ********************************************************************* */
__srecord* db$insert_into(__stable* p_table, __fields p_fields);

/* -------------------------------------------------- * 
 * -------------- End of the DML design ------------- *
 * -------------------------------------------------- * */

/* ********************************************************************* 
 * function : db$get_record
 * purpose  : get record from the p_position (position from 0) using the p_index
 * ********************************************************************* */
__srecord* db$get_record(__stable* p_table, 
                         const int p_index, 
                    const long int p_position);

/* ********************************************************************* 
 * function : db$delete_record
 * purpose  : delete record from the p_position (position from 0) by p_index
 * ********************************************************************* */
void db$delete_from(__stable* p_table, 
                    const int p_index,
               const long int p_position);

/* ********************************************************************* 
 * function : db$for_all
 * purpose  : loop statement on the list records
 * ********************************************************************* */
unsigned char  db$for_all(__stable* p_table, 
             __p_table_for_function p_table_for_function, 
                              void* p_args[]);

/* ********************************************************************* 
 * function : db$for_all_by_index
 * purpose  : loop statement on the list records by p_index 
 * ********************************************************************* */
unsigned char db$for_all_by_index(__stable* p_table, 
                                        int p_index,
                     __p_table_for_function p_table_for_function, 
                                      void* p_args[]);

/* -------------------------------------------------- * 
 * --------------- End of the Functions ------------- *
 * -------------------------------------------------- * */

#endif
